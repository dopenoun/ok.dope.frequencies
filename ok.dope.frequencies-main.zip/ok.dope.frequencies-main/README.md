# ok.dope.frequencies
Just open it up in Cloudflare as a static page and let it rip. 
